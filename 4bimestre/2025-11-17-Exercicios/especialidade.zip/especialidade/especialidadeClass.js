class especialidade {
    constructor (id, nome, area, tempo, conselho, posicaoNaLista){
        this.id = id;
        this.nome = nome;
        this.area = area;
        this.tempo = tempo;
        this.conselho = conselho; 

    this.posicaoNaLista = posicaoNaLista;
    }
}